<?php

#Don't change this
define("THEMENAME", $themename);
define("THEMESHORT", $themeshort);
define("IMGURL", get_template_directory_uri()."/img");
define("THEMEROOTURL", get_template_directory_uri());

$shortcodesUI = array();
$defaultUI = "";
$compileShortcodeUI = "";
$compile_with_video = "";
$title_custom_color = "";
$compile_without_video = "";
$cover = "";

?>